/* ============================================================
   Quiz Management System - Take Quiz
   Student 242046

   Plain JavaScript only. No library, no database, no PHP.

   The two things below already work: the clock in the corner and the
   sign in. Read them, they are good examples of what you are about to
   write. Do not delete them.

   YOUR CODE GOES AT THE BOTTOM, under "YOUR CODE".
   ============================================================ */

/* ---- the clock in the top corner, already working ---- */
function showClock() {
  var now = new Date();
  var h = String(now.getHours()).padStart(2, '0');
  var m = String(now.getMinutes()).padStart(2, '0');
  var s = String(now.getSeconds()).padStart(2, '0');
  document.getElementById('clock').textContent = h + ':' + m + ':' + s;
}
showClock();
setInterval(showClock, 1000);


/* ---- the sign in, already working ----
   The username and the password are written here in the code. That is
   fine for a class project. A real site would never do it this way. */
var ADMIN_USER = 'admin';
var ADMIN_PASS = '2026';

document.getElementById('loginBtn').onclick = function () {
  var user = document.getElementById('user').value;
  var pass = document.getElementById('pass').value;
  var msg  = document.getElementById('loginMsg');

  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    msg.textContent = '';
    document.getElementById('login').hidden = true;   // hide the login box
    document.getElementById('app').hidden = false;    // show your work
    
    

  } else {
    msg.className = 'bad';
    msg.textContent = 'Wrong username or password. Try admin / 2026.';
  }
};


/* ============================================================
   THE QUESTIONS
   Five questions to work with. Change the wording if you like, but
   keep the shape: a question, four options, and the right answer.
   ============================================================ */
var questions = [
  { question: "Which tag makes the largest heading?",
    options: ["<h1>", "<h6>", "<p>", "<div>"],
    answer:  "<h1>" },

  { question: "Which attribute gives an element a unique name?",
    options: ["class", "id", "name", "style"],
    answer:  "id" },

  { question: "Which CSS property changes the text colour?",
    options: ["background", "font", "color", "border"],
    answer:  "color" },

  { question: "Which method finds one element by its id?",
    options: ["querySelectorAll", "getElementById", "createElement", "appendChild"],
    answer:  "getElementById" },

  { question: "Which keyword declares a variable?",
    options: ["let", "make", "set", "define"],
    answer:  "let" }
];


/* ============================================================
   YOUR CODE

   start() runs the moment the user signs in. Build the quiz from here.

   1. Keep track of which question you are on, and of the score.
   2. Show the current question's text in the box with id "question".
   3. Loop over that question's options and make one button for each,
      inside the box with id "options".
   4. When an option is clicked, compare it with the right answer using
      if/else, and add one to the score when it is correct.
   5. The "Next question" button moves on to the next one.
   6. When there are no questions left, show the final score instead.
   7. Style what you built, at the bottom of css/style.css.

   Useful: document.createElement('button'), appendChild, .onclick,
   .textContent, questions.length

   Finished early? Make it better. A countdown for each question, a
   progress bar, a Restart button, a message that changes with the score.
   Anything you can do with HTML, CSS and JavaScript is allowed.
   ============================================================ */

  var current = 0;
  var score =0;
  var answered = false;


  function showQuestion(){
    answered = false;
    var q = questions[current];
    document.getElementById('question').textContent = q.question;
    var box = document.getElementById('options');
    box.innerHTML = '';
    for(var i = 0; i<q.options.length;i++){
      var btn = document.createElement('button');
     btn.textContent = q.options[i];
      btn.onclick = function () {
        checKAnswer(this,q);
        };
      box.appendChild(btn);
    }
    
  }

  function checKAnswer(btn,q){
    if (answered) return;
    answered = true;
    var all = document.getElementById('options').children;
    for(var j = 0; j < all.length; j++){
      all[j].disabled = true;
      if (all[j].textContent=== q.answer){
        all [j].className = 'correct';
      }
    }
    if(btn.textContent === q.answer){
      score = score + 1;
    }else{
      btn.className = 'wrong';
    }
  }
    
  function showScore() {
    document.getElementById('options').textContent= '';
   var qEl = document.getElementById('question');
qEl.className = 'score';
    qEl.textContent = 'Your score: ' + score + ' / ' + questions.length;
    var restartBtn = document.createElement('button');
    restartBtn.textContent = 'Restart Quiz';
    restartBtn.onclick = function(){
      current = 0;
      score = 0;
      qEl.className = '';

      document.getElementById('next').style.display = '';
      showQuestion();
    };
    document.getElementById('options').appendChild(restartBtn);
    document.getElementById('next').style.display = 'none';
  }


document.getElementById('next').onclick = function () {
  current = current + 1 ;
  if (current < questions.length){
    showQuestion();
  }else{
    showScore();
  }
};
showQuestion();