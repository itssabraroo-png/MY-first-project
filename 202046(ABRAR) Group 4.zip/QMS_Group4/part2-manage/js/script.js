/* ============================================================
   Quiz Management System - Manage Questions
   Student 242368

   Plain JavaScript only. No library, no database, no PHP.

   The two things below already work: the clock in the corner and the
   sign in. Read them, they are good examples of what you are about to
   write. Do not delete them.

   YOUR CODE GOES AT THE BOTTOM, under "YOUR CODE".
   ============================================================ */

/* ---- the clock in the top corner, already working ---- */
function showClock() {
  var now = new Date();
  var h = String(now.getHours()).padStart(2, '0');
  var m = String(now.getMinutes()).padStart(2, '0');
  var s = String(now.getSeconds()).padStart(2, '0');
  document.getElementById('clock').textContent = h + ':' + m + ':' + s;
}
showClock();
setInterval(showClock, 1000);


/* ---- the sign in, already working ----
   The username and the password are written here in the code. That is
   fine for a class project. A real site would never do it this way. */
var ADMIN_USER = 'admin';
var ADMIN_PASS = '2026';

document.getElementById('loginBtn').onclick = function () {
  var user = document.getElementById('user').value;
  var pass = document.getElementById('pass').value;
  var msg  = document.getElementById('loginMsg');

  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    msg.textContent = '';
    document.getElementById('login').hidden = true;   // hide the login box
    document.getElementById('app').hidden = false;    // show your work
    start();                                          // your code runs here
  } else {
    msg.className = 'bad';
    msg.textContent = 'Wrong username or password. Try admin / 2026.';
  }
};


/* ============================================================
   THE QUESTIONS ALREADY IN THE SYSTEM
   Two to start with, so the page shows something straight away.
   ============================================================ */
var questions = [
  { question: "Which tag makes a paragraph?",
    options: ["<p>", "<h1>", "<br>", "<li>"],
    answer:  "<p>" },

  { question: "Which CSS property sets the space inside a box?",
    options: ["margin", "padding", "border", "gap"],
    answer:  "padding" }
];


/* ============================================================
   YOUR CODE

   start() runs the moment the user signs in.

   1. Write a function that shows every question in the list, inside the
      box with id "list". Use a loop over the questions array.
   2. Call it once in start(), so the two questions above appear.
   3. When "Add question" is clicked, read the six boxes with .value
   4. If any of them is empty, show a message in "formMsg" and do not add
      anything.
   5. Otherwise build the new question in the same shape as the two above,
      push it onto the array, and show the list again.
   6. Clear the boxes after adding, ready for the next one.
   7. Give every question in the list a Delete button that removes it.
   8. Style the form and the list, at the bottom of css/style.css.

   Useful: .value, questions.push(...), questions.splice(i, 1),
   document.createElement, appendChild, innerHTML = ''

   Finished early? Make it better. A count of how many questions there
   are, an Edit button, a warning when the right answer is not one of the
   four options, a search box.
   ============================================================ */


function showQuestions() {
  var list = document.getElementById('list');
  list.innerHTML = '';

  for (var i = 0; i <questions.length; i++){
    var item = document.createElement('div');

    var title = document.createElement('h3');
    title.textContent = questions[i].question;
    item.appendChild(title);

    var options = document.createElement('p');
    options.textContent = questions[i].options.join(' | ');
    item.appendChild(options);

    var answer = document.createElement('p');
    answer.textContent = 'Answer: ' + questions[i].answer;
    item.appendChild(answer);

    var deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.onclick = (function(index){
      return function(){
        questions.splice(index, 1);
        showQuestions();
      };
    })(i);
    item.appendChild(deleteBtn);
    list.appendChild(item);
  }
}
  function start() {

    showQuestions();
    var msg = document.getElementById('formMsg');

    document.getElementById('addBtn').onclick = function () {

      var question = document.getElementById('qText').value.trim();

      var opt1 = document.getElementById('opt1').value.trim();
      var opt2 = document.getElementById('opt2').value.trim();
      var opt3 = document.getElementById('opt3').value.trim();
      var opt4 = document.getElementById('opt4').value.trim();

      var answer = document.getElementById('qAnswer').value.trim();

      if (!question || !opt1 ||!opt2 ||!opt3 ||!opt4 || !answer) {
        msg.textContent = 'please fill all fields.';
        return;
      }
      questions.push({
        question: question,
        options: [opt1, opt2 ,opt3 ,opt4],
        answer: answer
      }) ;
      msg.textContent = 'Question added successfully!';

      document.getElementById('qText').value = '';
      document.getElementById('opt1').value = '';
      document.getElementById('opt2').value ='';
      document.getElementById('opt3').value ='';
      document.getElementById('opt4').value ='';

      showQuestions();
    };
  }