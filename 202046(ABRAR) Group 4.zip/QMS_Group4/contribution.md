# Contribution

Quiz Management System - COWE2100

Fill this in before you upload the project to SULMS. Write it yourself, in
your own words. Short answers are fine; honest ones matter more than long
ones.

## The group

| Member | Student ID | Name | Part built |
|--------|-----------|------|------------|
| 1      |           |      | Part 1 - Take Quiz |
| 2      |           |      | Part 2 - Manage Questions |
| 3      |           |      | Part 3 - Home and Navigation |

Delete the rows your group does not have.

## What I did

Write a few lines about the part you built. Name the files you wrote and
the main things your code does.



## Where I got stuck, and what fixed it

The errors you hit and how you got past them. This is the most useful part
of the whole file, so do not leave it empty.



## Help I gave or received

Working together is allowed and expected. Say who helped you and what with,
and who you helped. Saying "nobody" is a perfectly good answer.



## Anything else

Anything you want read before this is marked.
